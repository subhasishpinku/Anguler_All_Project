import { ValidateUserNameDirective } from './validate-user-name.directive';

describe('ValidateUserNameDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidateUserNameDirective();
    expect(directive).toBeTruthy();
  });
});
