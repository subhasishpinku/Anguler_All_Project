export class TodoList{
    constructor(
        public title:string,
        public description:string,
        public created:any
    ){}
}