// Define base_url :
const base_url='http://localhost:3000/';
const uploadDir='uploads/'
module.exports=base_url+uploadDir;
console.log('Base_url is ready to use');